// pages/shoppingCart/shoppingCart.js
let _self;
const app=getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    carts:[],
    allSelector:true,
    total:0,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    _self=this;
    _self.setData({carts:app.globalData.carts});
    this.computerOrder();
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  allSelector:function(event){
   let bool=this.data.allSelector;
   this.setData({allSelector:!bool});
   let shoppingCarts=this.data.carts;
   shoppingCarts.forEach(element=>element.selected=!bool);
   this.setData({carts:shoppingCarts});
   this.computerOrder();
  },
  productSelector:function(event){
    let currentId=event.currentTarget.dataset.id;
    let shoppingCarts=this.data.carts;
    let select=shoppingCarts.find(element=>element.id==currentId).selected;
    shoppingCarts.find(element => element.id == currentId).selected=!select;
    if(shoppingCarts.every(element=>element.selected==false)){
      this.setData({allSelector:false});
    }else{
      this.setData({allSelector:true});
    }
    this.setData({carts:shoppingCarts});
    this.computerOrder();
  },
  addOperation:function(event){
    let currentId=event.currentTarget.dataset.id;
    let shoppingCarts=this.data.carts;
    shoppingCarts.find(element=>element.id==currentId).count++;
    this.setData({carts:shoppingCarts});
    this.computerOrder();
  },
  reduceOperation:function(event){
    let currentId = event.currentTarget.dataset.id;
    let shoppingCarts = this.data.carts;
    if(shoppingCarts.find(element => element.id == currentId).count>1){
      shoppingCarts.find(element=>element.id==currentId).count--;
    }else{
      let currentIndex=shoppingCarts.findIndex(element=>element.id=currentId);
      shoppingCarts.splice(currentIndex,1);
    }
    this.setData({ carts: shoppingCarts });
    this.computerOrder();
  },
  computerOrder:function(){
    let shoppingCarts=this.data.carts;
    let tempTotal=0;
    tempTotal=shoppingCarts.filter(element=>element.selected).reduce((prev,element)=>
      prev+element.count*element.real,0);
    this.setData({total:tempTotal});
  }
})