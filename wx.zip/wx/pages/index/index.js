//index.js
//获取应用实例
const app = getApp()
let _self;
Page({
  data:{
    deskId:'1',
    currentId:'0',
    products:[
      {"id":"1","path":"/images/products/dsx.jpg","name":"木须肉","num":30,"preace":37,"real":27,"num1":"3","count":"1","selected":true},
      {"id":"2","path":"/images/products/hxgdt.jpg","name":"汤","num": 30,"preace":37,"real":27,"num1":"1","count":"1","selected":true},
      {"id":"3","path":"/images/products/jzdc.jpg","name":"羊肉块","num": 30,"preace":37,"real":27,"num1":"2","count":"1","selected":true},
      {"id":"4","path":"/images/products/sd.jpg","name":"圣代","num": 30,"preace":37,"real":27,"num1":"4","count":"1","selected":true},
    ],
    tempProducts:[
      {"num1":"1","typename":"汤类"},
      {"num1":"2","typename":"折扣"},
      {"num1":"3","typename":"热卖"},
      {"num1":"4","typename":"特色菜"},
    ],
    imageUrls: [
      '/images/index/haibao-1.jpg', 
      '/images/index/haibao-2.jpg', 
      '/images/index/haibao-3.jpg', 
      '/images/index/haibao-4.jpg', 
      '/images/index/haibao-5.jpg'],
    types:[{"id":"1","name":"汤类"},
            {"id":"2", "name": "折扣" },
            {"id":"3", "name": "热卖" },
            {"id":"4", "name": "特色菜" },
          ]

  },
  onLoad:function(){

  },
  onShow:function(){
    let temp = this.data.products;
    this.data.carts=app.globalData.carts;
    this.setData({tempProducts:temp})
  },
  getDeskId:function(){
    _self=this;
    wx.scanCode({
      onlyFromCamera:true,
      success:res=>{
        if(res.result!=null){
          let id=res.result.split('=')[1];
          _self.setData({deskId:id});
        }
      }
    });
  },
  switchTab:function(event){
    _self = this;
    let tabId = event.currentTarget.dataset.tabId;
    let typeArray;
    _self.setData({currentId:tabId})
    if(tabId==0){
      typeArray = _self.data.products;
    }else{
      typeArray = _self.data.products.filter(element=>element.num1==tabId);
    }
    _self.setData({currentId:tabId,tempProducts:typeArray})
  },
  addCarts:function(event){
    let productId=event.currentTarget.dataset.id;
    let product = this.data.products.find(element=>element.id==productId);
    if (this.data.carts.includes(product)){
      this.data.carts.find(element=>element.id==productId).count++;
    }else{
      this.data.carts.push(product);
    }
    app.globalData.carts=this.data.carts;
  }
})